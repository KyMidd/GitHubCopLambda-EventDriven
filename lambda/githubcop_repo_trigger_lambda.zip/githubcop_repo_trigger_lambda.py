from __future__ import print_function
import json
import boto3
import sys
from botocore.exceptions import ClientError
import hashlib
import hmac
import re
from urllib.parse import unquote

# botocore.vendored present in Lambda hosted environment, but not local
from botocore.vendored import requests # For lambda-hosted runs
#import requests # For local testing

# Calculate the signature
def calculate_signature(github_signature, githhub_payload):
    signature_bytes = bytes(github_signature, 'utf-8')
    digest = hmac.new(key=signature_bytes, msg=githhub_payload, digestmod=hashlib.sha1)
    signature = digest.hexdigest()
    return signature

# Validate the signature
def validate_signature(GITHUB_SECRET, event, body):
  
  incoming_signature = re.sub(r'^sha1=', '', event['headers']['X-Hub-Signature'])
  incoming_payload = unquote(re.sub(r'^payload=', '', event['body']))
  calculated_signature = calculate_signature(GITHUB_SECRET, incoming_payload.encode('utf-8'))

  if incoming_signature != calculated_signature:
    print("Unauthorized attempt")
    sys.exit()
  else:
    print("🚀 Confirmed HMAC matches, authorized access, continuing")
  
# Isolate the event body from the event package
def isolate_event_body(event):
  # Dump the event to a string, then load it as a dict
  event_string = json.dumps(event, indent=2)
  event_dict = json.loads(event_string)
  
  # Isolate the event body from event package
  event_body = event_dict['body']
  body = json.loads(event_body)
  
  # Return the event
  return body

# Get the event action
def check_event_action(event):
    
  # Check action of event
  action = event['action']
  
  # If action isn't "created", exit
  if action != 'created':
    print("🚫 Event action detected as: " + action)
    print("🚫 Event is not creating a repo, exiting")

    # Return 200 code
    return {
      'statusCode': 200,
      'body': json.dumps("Since action is ", action, ", and not 'created', we are exiting")
    }

    # Exit script
    sys.exit()
  else:
    print("🚀 Successfully detected action: " + action)

  # Get repo name
  repo_name = event['repository']['name']
  print("🚀 Successfully detected repo: " + repo_name)
  return repo_name

# Get GitHubPAT secret from AWS Secrets Manager that we'll use to start the githubcop workflow
def get_secret(secret_name, region_name):
  
  # Create a Secrets Manager client
  session = boto3.session.Session()
  client = session.client(
    service_name='secretsmanager',
    region_name=region_name
  )

  try:
    get_secret_value_response = client.get_secret_value(
      SecretId=secret_name
    )
  except ClientError as e:
    # For a list of exceptions thrown, see
    # https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
    print("Had an error attempting to get secret from AWS Secrets Manager:", e)
    raise e

  # Decrypts secret using the associated KMS key.
  secret = get_secret_value_response['SecretString']

  # Print happy joy joy
  print("🚀 Successfully got secret", secret_name, "from AWS Secrets Manager")
  
  # Return the secret
  return secret

# Start repo cop workflow targeting a single repo
def start_repo_cop_targeted(repo_name, PAT):

  # Define new data to create
  payload = {
    "ref": "master",
    "inputs": {
      "repo-to-police": repo_name
    }
  }
  print("🚀 Successfully created payload")

  post_headers = {
    "Accept": "application/vnd.github+json",
    "Authorization": "Bearer " + PAT,
    "X-GitHub-Api-Version": "2022-11-28"
  }
  print("🚀 Successfully created post headers")

  # The API endpoint to communicate with
  url_post = "https://api.github.com/repos/practicefusion/GitHubCop/actions/workflows/github_repo_cop.yml/dispatches"

  # A POST request to tthe API
  try:
    post_response = requests.post(
      url_post,
      headers=post_headers,
      json=payload
    )
  except ClientError as e:
    # For a list of exceptions thrown, see
    # https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
    raise e

  if post_response.status_code != 204:
    print("🚨 Error: ", post_response.status_code)
    print(post_response.text)
    sys.exit()

def return_response_code():
  return {
    'statusCode': 200,
    'body': json.dumps('Processed by GitHubCop Trigger Lambda!')
  }

# Main function
def lambda_handler(event, context):

  print("🚀 Lambda execution starting")

  # Isolate the event body from the event package
  body = isolate_event_body(event)

  # Fetch the webhook secret from secrets manager
  GITHUB_SECRET = get_secret("PfGitHubWebhookSecret", "us-east-1")

  # Validate the signature
  validate_signature(GITHUB_SECRET, event, body)
  
  # Check event action. If new repo added, get repo name. Else, exit
  repo_name = check_event_action(body)

  # Get the PAT from secrets manager
  PAT = get_secret("GitHubPAT", "us-east-1")

  # Start the githubcop workflow
  start_repo_cop_targeted(repo_name, PAT)

  # Print happy joy joy
  print("🚀 Successfully started repo cop workflow targeting repo: " + repo_name)

  # Return response code
  return return_response_code()


#---- This section is for local testing

# Store dummy data for testing
#event = {'resource': '/', 'path': '/', 'httpMethod': 'POST', 'headers': {'Accept': '*/*', 'CloudFront-Forwarded-Proto': 'https', 'CloudFront-Is-Desktop-Viewer': 'true', 'CloudFront-Is-Mobile-Viewer': 'false', 'CloudFront-Is-SmartTV-Viewer': 'false', 'CloudFront-Is-Tablet-Viewer': 'false', 'CloudFront-Viewer-ASN': '36459', 'CloudFront-Viewer-Country': 'US', 'content-type': 'application/json', 'Host': 'gs6733m6sa.execute-api.us-east-1.amazonaws.com', 'User-Agent': 'GitHub-Hookshot/0a3a2d2', 'Via': '1.1 170caffbbbc9abe2c5fd15f4f58b75b4.cloudfront.net (CloudFront)', 'X-Amz-Cf-Id': 'TetOtrVizhP7BUeDjd6fo4FS8RXfS-QKgbDkKK2opStYfRXCtrG0kQ==', 'X-Amzn-Trace-Id': 'Root=1-64456faa-0317c7da1a44348238bc47d6', 'X-Forwarded-For': '140.82.115.157, 15.158.41.235', 'X-Forwarded-Port': '443', 'X-Forwarded-Proto': 'https', 'X-GitHub-Delivery': '324bec60-e1ff-11ed-8e8f-db169bae3a53', 'X-GitHub-Event': 'installation_repositories', 'X-GitHub-Hook-ID': '410652868', 'X-GitHub-Hook-Installation-Target-ID': '321246', 'X-GitHub-Hook-Installation-Target-Type': 'integration', 'X-Hub-Signature': 'sha1=8f796371d5a71092eba3bf96534cd46e60e94c6e', 'X-Hub-Signature-256': 'sha256=ad3f7f5f25e3dd53dcb2df17b7c04c82aff73714faa12bc240fe8dee7c275d8d'}, 'multiValueHeaders': {'Accept': ['*/*'], 'CloudFront-Forwarded-Proto': ['https'], 'CloudFront-Is-Desktop-Viewer': ['true'], 'CloudFront-Is-Mobile-Viewer': ['false'], 'CloudFront-Is-SmartTV-Viewer': ['false'], 'CloudFront-Is-Tablet-Viewer': ['false'], 'CloudFront-Viewer-ASN': ['36459'], 'CloudFront-Viewer-Country': ['US'], 'content-type': ['application/json'], 'Host': ['gs6733m6sa.execute-api.us-east-1.amazonaws.com'], 'User-Agent': ['GitHub-Hookshot/0a3a2d2'], 'Via': ['1.1 170caffbbbc9abe2c5fd15f4f58b75b4.cloudfront.net (CloudFront)'], 'X-Amz-Cf-Id': ['TetOtrVizhP7BUeDjd6fo4FS8RXfS-QKgbDkKK2opStYfRXCtrG0kQ=='], 'X-Amzn-Trace-Id': ['Root=1-64456faa-0317c7da1a44348238bc47d6'], 'X-Forwarded-For': ['140.82.115.157, 15.158.41.235'], 'X-Forwarded-Port': ['443'], 'X-Forwarded-Proto': ['https'], 'X-GitHub-Delivery': ['324bec60-e1ff-11ed-8e8f-db169bae3a53'], 'X-GitHub-Event': ['installation_repositories'], 'X-GitHub-Hook-ID': ['410652868'], 'X-GitHub-Hook-Installation-Target-ID': ['321246'], 'X-GitHub-Hook-Installation-Target-Type': ['integration'], 'X-Hub-Signature': ['sha1=8f796371d5a71092eba3bf96534cd46e60e94c6e'], 'X-Hub-Signature-256': ['sha256=ad3f7f5f25e3dd53dcb2df17b7c04c82aff73714faa12bc240fe8dee7c275d8d']}, 'queryStringParameters': None, 'multiValueQueryStringParameters': None, 'pathParameters': None, 'stageVariables': None, 'requestContext': {'resourceId': 'f0hs65fyfd', 'resourcePath': '/', 'httpMethod': 'POST', 'extendedRequestId': 'D15inGxQIAMFb-A=', 'requestTime': '23/Apr/2023:17:49:30 +0000', 'path': '/cop/', 'accountId': '072100331905', 'protocol': 'HTTP/1.1', 'stage': 'cop', 'domainPrefix': 'gs6733m6sa', 'requestTimeEpoch': 1682272170034, 'requestId': '6bea38b0-d71a-47b7-b753-fbbe280f70a1', 'identity': {'cognitoIdentityPoolId': None, 'accountId': None, 'cognitoIdentityId': None, 'caller': None, 'sourceIp': '140.82.115.157', 'principalOrgId': None, 'accessKey': None, 'cognitoAuthenticationType': None, 'cognitoAuthenticationProvider': None, 'userArn': None, 'userAgent': 'GitHub-Hookshot/0a3a2d2', 'user': None}, 'domainName': 'gs6733m6sa.execute-api.us-east-1.amazonaws.com', 'apiId': 'gs6733m6sa'}, 'body': '{"action":"added","installation":{"id":36627756,"account":{"login":"practicefusion","id":61248795,"node_id":"MDEyOk9yZ2FuaXphdGlvbjYxMjQ4Nzk1","avatar_url":"https://avatars.githubusercontent.com/u/61248795?v=4","gravatar_id":"","url":"https://api.github.com/users/practicefusion","html_url":"https://github.com/practicefusion","followers_url":"https://api.github.com/users/practicefusion/followers","following_url":"https://api.github.com/users/practicefusion/following{/other_user}","gists_url":"https://api.github.com/users/practicefusion/gists{/gist_id}","starred_url":"https://api.github.com/users/practicefusion/starred{/owner}{/repo}","subscriptions_url":"https://api.github.com/users/practicefusion/subscriptions","organizations_url":"https://api.github.com/users/practicefusion/orgs","repos_url":"https://api.github.com/users/practicefusion/repos","events_url":"https://api.github.com/users/practicefusion/events{/privacy}","received_events_url":"https://api.github.com/users/practicefusion/received_events","type":"Organization","site_admin":false},"repository_selection":"all","access_tokens_url":"https://api.github.com/app/installations/36627756/access_tokens","repositories_url":"https://api.github.com/installation/repositories","html_url":"https://github.com/organizations/practicefusion/settings/installations/36627756","app_id":321246,"app_slug":"practicefusion-githubcop","target_id":61248795,"target_type":"Organization","permissions":{"actions":"write","contents":"write","metadata":"read","workflows":"write","pull_requests":"write","administration":"write","organization_events":"read","organization_administration":"write"},"events":[],"created_at":"2023-04-19T13:45:39.000-05:00","updated_at":"2023-04-19T13:45:39.000-05:00","single_file_name":null,"has_multiple_single_files":false,"single_file_paths":[],"suspended_by":null,"suspended_at":null},"repository_selection":"all","repositories_added":[{"id":631655032,"node_id":"R_kgDOJaZKeA","name":"kyler-test-repo-5","full_name":"practicefusion/kyler-test-repo-5","private":true}],"repositories_removed":[],"requester":null,"sender":{"login":"KyMidd","id":13367556,"node_id":"MDQ6VXNlcjEzMzY3NTU2","avatar_url":"https://avatars.githubusercontent.com/u/13367556?v=4","gravatar_id":"","url":"https://api.github.com/users/KyMidd","html_url":"https://github.com/KyMidd","followers_url":"https://api.github.com/users/KyMidd/followers","following_url":"https://api.github.com/users/KyMidd/following{/other_user}","gists_url":"https://api.github.com/users/KyMidd/gists{/gist_id}","starred_url":"https://api.github.com/users/KyMidd/starred{/owner}{/repo}","subscriptions_url":"https://api.github.com/users/KyMidd/subscriptions","organizations_url":"https://api.github.com/users/KyMidd/orgs","repos_url":"https://api.github.com/users/KyMidd/repos","events_url":"https://api.github.com/users/KyMidd/events{/privacy}","received_events_url":"https://api.github.com/users/KyMidd/received_events","type":"User","site_admin":false}}', 'isBase64Encoded': False}

# Lambda handler
#lambda_handler(event, 'context')

#---- End of local testing section